import express from "express";
import { upload } from "../middleware/upload.middleware.js";
import { deleteImage, uploadImage } from "../controllers/upload.controller.js";


const router = express.Router();

router.post("/avatar", upload.single("avatar"), uploadImage);
router.delete("/avatar", deleteImage);

export default router;