import express from 'express';
import { createPost, getPost } from '../controllers/post.controller.js';
import { auth } from '../middleware/auth.js';
import { upload } from '../middleware/upload.middleware.js';

const router = express.Router();

// 1. Create a Post with Image Upload (Professional way: /api/v1/posts/)
router.post('/', auth(), upload.single('image'), createPost);

// 2. Fetch a Post and Populate the Multi-size images
router.get('/:id', getPost);

export default router;
