import { S3Client, PutObjectCommand,DeleteObjectCommand } from '@aws-sdk/client-s3';
import crypto from 'crypto';
import path from 'path';

// 1. Initialize S3 Client (Requires AWS credentials in your .env)
const s3Client = new S3Client({
    region: process.env.AWS_REGION,
    credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    }
});


export const uploadImageToS3 = async (fileBuffer, originalName, mimetype) => {
    const uniqueSuffix = crypto.randomBytes(16).toString('hex');
    const ext = path.extname(originalName).toLowerCase();
    const fileName = `uploads/${uniqueSuffix}${ext}`; 

    const command = new PutObjectCommand({
        Bucket: process.env.AWS_S3_BUCKET_NAME,
        Key: fileName,
        Body: fileBuffer,
        ContentType: mimetype,
    });

    await s3Client.send(command);

    return {
        s3Url: `https://${process.env.AWS_S3_BUCKET_NAME}.s3.${process.env.AWS_REGION}.amazonaws.com/${fileName}`,
        s3Key: fileName
    };
};


export const deleteImageFromS3 = async(key)=>{

    if(!key)return;
    const command = new DeleteObjectCommand({
        Bucket: process.env.AWS_S3_BUCKET_NAME,
        Key: key,
    })
    await s3Client.send(command);

}