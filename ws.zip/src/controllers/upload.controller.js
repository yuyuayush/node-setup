import { deleteImageFromS3, uploadImageToS3 } from "../services/s3.service.js";
import { successResponse } from "../utils/responseHandler.js";
import sharp from "sharp";
import { ApiError } from "../utils/ApiError.js";
import { asyncHandler } from "../utils/asyncHandler.js";

export const uploadImage = asyncHandler(async (req, res) => {

    const file = req?.file;
    const user = req.user;
    if (!file) {
        throw new ApiError(400, "File is required");
    }

    const compressedBuffer = await sharp(req.file.buffer)
        .resize(500, 500, { fit: 'cover' })
        .jpeg({ quality: 80 })
        .toBuffer();

    const { s3Url, s3Key } = await uploadImageToS3(compressedBuffer, file.originalname, file.mimetype);

    if (user.avatarKey) {
        await deleteImageFromS3(user.avatarKey);
    }

    user.avatarKey = s3Key;
    user.avatarUrl = s3Url;
    await user.save();

    return successResponse(res, { s3Url, s3Key }, "File uploaded successfully", 200);

})

export const deleteImage = asyncHandler(async (req, res) => {

    const user = req.user;
    if (user.avatarKey) await deleteImageFromS3(user.avatarKey);
    user.avatarKey = null;
    user.avatarUrl = null;
    await user.save();
    return successResponse(res, {}, "File deleted successfully", 200);

})