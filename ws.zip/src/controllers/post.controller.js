import { ApiError } from "../utils/ApiError.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import Post from '../models/post.model.js';
import { Worker } from "node:worker_threads";
import { fileURLToPath } from "node:url";
import path from "node:path";
import Image from "../models/image.model.js";
import { uploadImageToS3 } from "../services/s3.service.js";
import { successResponse } from "../utils/responseHandler.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const createPost = asyncHandler(async (req, res) => {
    const { title, content } = req.body;
    const user = req.user;
    const file = req.file;

    if (!file) {
        throw new ApiError(400, "file is required")
    }

    const workerPath = "../workers/learn.js";

    const results = await new Promise((resolve, reject) => {
        const worker = new Worker(path.join(__dirname, workerPath), { workerData: file.buffer });
        worker.on("message", (obj) => obj.success ? resolve(obj.results) : reject(obj.error));
        worker.on("error", reject);
    });

    const [mobile, laptop, desktop] = await Promise.all([
        uploadImageToS3(results.mobile, file.originalname, 'image/webp'),
        uploadImageToS3(results.laptop, file.originalname, 'image/webp'),
        uploadImageToS3(results.desktop, file.originalname, 'image/webp')
    ]);

    const imageDocs = await Image.create({
        mobileUrl: mobile.s3Url,
        mobileKey: mobile.s3Key,
        laptopUrl: laptop.s3Url,
        laptopKey: laptop.s3Key,
        desktopUrl: desktop.s3Url,
        desktopKey: desktop.s3Key,
        owner: user._id
    });

    const post = await Post.create({
        title,
        content,
        image: imageDocs._id,
        author: user._id,
    });

    return successResponse(res, post, "Post created successfully", 200);
});

export const getPostByUser = asyncHandler(async (req, res) => {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    const posts = await Post.aggregate([
        {
            $match: {
                author: req.user._id
            }
        },
        { $sort: { createdAt: -1 } },
        { $skip: skip },
        { $limit: limit },
        {
            $lookup: {
                from: "images",
                localField: "image",
                foreignField: "_id",
                as: "image"
            }
        },
        { $unwind: "$image" },
        {
            $project: {
                title: 1,
                content: 1,
                "image.desktopUrl": 1
            }
        }
    ]);

    return successResponse(res, posts, "User posts fetched successfully", 200);
});

export const getPost = asyncHandler(async (req, res) => {
    const post = await Post.findById(req.params.id).populate("image");
    if (!post) {
        throw new ApiError(404, "Post not found");
    }
    return successResponse(res, post, "Post fetched successfully", 200);
});

export const getAllPosts = asyncHandler(async (req, res) => {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    const posts = await Post.aggregate([
        { $sort: { createdAt: -1 } },
        { $skip: skip },
        { $limit: limit },
        {
            $lookup: {
                from: "images",
                localField: "image",
                foreignField: "_id",
                as: "image"
            }
        },
        { $unwind: "$image" },
        {
            $project: {
                title: 1,
                content: 1,
                "image.desktopUrl": 1
            }
        }
    ]);

    return successResponse(res, posts, "Posts fetched successfully", 200);
});